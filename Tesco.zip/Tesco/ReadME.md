# HOW TO EXECUTE

1. Open the terminal and navigate to your project directory.

2. Run `npm install` in order to install all dependencies needed for this application.

# Use `npm start ` command to run the server.js file in that dsirectory. When the server runs successfully, you will see a message like this:Server is running on port 2880 .

# Open http://localhost:2880 in any of your browser.

#ERRORS

# No Known ERRORS.
